const fs = require('fs')
const Client = require("./ws.js");
require('express')().listen(3000)
const statuss = ['online', 'dnd', 'idle']
const tokens = fs.readFileSync('tokens.txt', 'utf-8').replace(/\r|\x22/gi, '').split('\n');
if (tokens.length == 0 || !tokens[0][0]) return console.log('There is no tokens in file .')

process.on('uncaughtException', e => console.log(e));
process.on('uncaughtRejection', e => console.log(e));

let x = 0
let i = 1
tokens.forEach(async token => {
let status = statuss[Math.floor(Math.random() * statuss.length)]
  if (i == tokens.length) {
console.log()
console.log()
console.log(`\x1b[31mTotal: ${i} Vaild: ${i-x} Invaild: ${x}`)
console.log()
console.log()
}
  i++
await new Client(token, status)
})


